package com.capstone.BloqCert.services;

import com.capstone.BloqCert.dtos.DocumentDto;
import java.util.List;

public interface DocumentService {
    List<String> createDocument(DocumentDto documentDto);
    List<DocumentDto> getDocumentsByUserId(Long userId);
}