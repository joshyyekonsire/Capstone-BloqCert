package com.capstone.BloqCert.controllers;
import com.capstone.BloqCert.dtos.UserDto;
import com.capstone.BloqCert.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:63342")
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public List<String> addUser(@RequestBody UserDto userDto){
        return userService.createUser(userDto);
    }
    @GetMapping
    public UserDto getUserByEmailAndPassword(@RequestParam String email, @RequestParam String password) {
        return userService.getUserByEmailAndPassword(email, password);
    }
}
