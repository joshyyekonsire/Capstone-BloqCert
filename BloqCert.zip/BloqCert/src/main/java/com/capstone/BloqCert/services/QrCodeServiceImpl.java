package com.capstone.BloqCert.services;

import com.capstone.BloqCert.dtos.QrCodeDto;
import com.capstone.BloqCert.entities.QrCode;
import com.capstone.BloqCert.repositories.QrCodeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class QrCodeServiceImpl implements QrCodeService {

    @Autowired
    private QrCodeRepository qrCodeRepository;

    @Override
    public QrCodeDto createQrCode(QrCodeDto qrCodeDto) {
        QrCode qrCode = new QrCode(qrCodeDto);
        qrCode = qrCodeRepository.save(qrCode);
        return new QrCodeDto(qrCode);
    }

    @Override
    public List<QrCodeDto> getQrCodesByUserId(Long userId) {
        List<QrCode> qrCodes = qrCodeRepository.findByUserId(userId);
        List<QrCodeDto> qrCodeDtos = new ArrayList<>();
        for (QrCode qrCode : qrCodes) {
            qrCodeDtos.add(new QrCodeDto(qrCode));
        }
        return qrCodeDtos;
    }
}