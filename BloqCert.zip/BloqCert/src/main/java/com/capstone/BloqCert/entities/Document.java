package com.capstone.BloqCert.entities;

import com.capstone.BloqCert.dtos.DocumentDto;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "documents")
public class Document {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private String type;
    private String document;
    private String name;

    public Document() {}

    public Document(DocumentDto documentDto) {
        if (documentDto.getUserId() != null) {
            this.userId = documentDto.getUserId();
        }
        if (documentDto.getType() != null) {
            this.type = documentDto.getType();
        }
        if (documentDto.getDocument() != null) {
            this.document = documentDto.getDocument();
        }
        if (documentDto.getName() != null) {
            this.name = documentDto.getName();
        }
    }

    public Document(Long userId) {
        this.userId = userId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDocument() {
        return document;
    }

    public void setDocument(String document) {
        this.document = document;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}