package com.capstone.BloqCert.services;

import com.capstone.BloqCert.dtos.DocumentDto;
import com.capstone.BloqCert.entities.Document;
import com.capstone.BloqCert.repositories.DocumentRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;


@Service
public class DocumentServiceImpl implements DocumentService {

    @Autowired
    private DocumentRepository documentRepository;

    @Override
    @Transactional
    public List<String> createDocument(DocumentDto documentDto) {
        List<String> response = new ArrayList<>();
        Document document = new Document(documentDto);
        documentRepository.saveAndFlush(document);
        response.add("upload success!");
        return response;
    }

    @Override
    public List<DocumentDto> getDocumentsByUserId(Long userId) {
        List<Document> documents = documentRepository.findByUserId(userId);
        List<DocumentDto> documentDtos = new ArrayList<>();
        for (Document document : documents) {
            documentDtos.add(new DocumentDto(document));
        }
        return documentDtos;
    }

}