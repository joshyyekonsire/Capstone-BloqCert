package com.capstone.BloqCert;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BloqCertApplication {

	public static void main(String[] args) {
		SpringApplication.run(BloqCertApplication.class, args);
	}

}
