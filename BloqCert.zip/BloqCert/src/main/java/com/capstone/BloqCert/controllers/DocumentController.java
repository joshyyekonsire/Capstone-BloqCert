package com.capstone.BloqCert.controllers;

import com.capstone.BloqCert.dtos.DocumentDto;
import com.capstone.BloqCert.services.DocumentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:63342")
@RequestMapping("/documents")
public class DocumentController {

    @Autowired
    private DocumentService documentService;

    @PostMapping("/upload")
    public List<String> addDocument(@RequestBody DocumentDto documentDto) {
        return documentService.createDocument(documentDto);
    }

    @GetMapping(params = "userId")
    public List<DocumentDto> getDocumentsByUserId(@RequestParam Long userId) {
        return documentService.getDocumentsByUserId(userId);
    }

    @GetMapping("/user-documents/{userId}")
    public List<DocumentDto> getUserDocuments(@PathVariable Long userId) {
        return documentService.getDocumentsByUserId(userId);
    }


}
