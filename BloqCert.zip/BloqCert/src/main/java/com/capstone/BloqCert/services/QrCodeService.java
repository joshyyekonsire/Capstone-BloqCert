package com.capstone.BloqCert.services;

import com.capstone.BloqCert.dtos.QrCodeDto;
import java.util.List;


public interface QrCodeService {
    QrCodeDto createQrCode(QrCodeDto qrCodeDto);
    List<QrCodeDto> getQrCodesByUserId(Long userId);

}
