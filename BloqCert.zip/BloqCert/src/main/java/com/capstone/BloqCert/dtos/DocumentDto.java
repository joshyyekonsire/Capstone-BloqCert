package com.capstone.BloqCert.dtos;

import com.capstone.BloqCert.entities.Document;

public class DocumentDto {
    private Long userId;
    private String document;
    private String type;
    private String name;

    public DocumentDto() {}

    public DocumentDto(Document document) {
        this.userId = document.getUserId();
        this.document = document.getDocument();
        this.type = document.getType();
        this.name = document.getName();
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getDocument() {
        return document;
    }

    public void setDocument(String document) {
        this.document = document;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}