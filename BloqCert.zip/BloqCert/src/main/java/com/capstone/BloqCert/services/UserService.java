package com.capstone.BloqCert.services;
import com.capstone.BloqCert.dtos.UserDto;
import jakarta.transaction.Transactional;
import java.util.List;

public interface UserService {
    @Transactional
    List<String> createUser(UserDto userDto);

    UserDto getUserByEmailAndPassword(String email, String password);
    List<UserDto> getAllUsers();
}
