package com.capstone.BloqCert.dtos;

import com.capstone.BloqCert.entities.QrCode;

public class QrCodeDto {
    private Long id;
    private Long userId;
    private String profilePicture;
    private String description;
    private String qrCode;

    public QrCodeDto() {}

    public QrCodeDto(Long userId, String profilePicture, String description, String qrCode) {
        this.userId = userId;
        this.profilePicture = profilePicture;
        this.description = description;
        this.qrCode = qrCode;
    }

    public QrCodeDto(QrCode qrCode) {
        this.id = qrCode.getId();
        this.userId = qrCode.getUserId();
        this.profilePicture = qrCode.getProfilePicture();
        this.description = qrCode.getDescription();
        this.qrCode = qrCode.getQrCode();
    }

    public QrCodeDto(Long id, Long userId, String profilePicture, String description, String qrcode) {
        this.id = id;
        this.userId = userId;
        this.profilePicture = profilePicture;
        this.description = description;
        this.qrCode = qrcode;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getProfilePicture() {
        return profilePicture;
    }

    public void setProfilePicture(String profilePicture) {
        this.profilePicture = profilePicture;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }
}