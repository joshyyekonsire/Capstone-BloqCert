package com.capstone.BloqCert.entities;

import com.capstone.BloqCert.dtos.QrCodeDto;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "qr_codes")
public class QrCode {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;

    private String profilePicture;

    private String description;

    private String qrcode;

    public QrCode() {}

    public QrCode(Long userId, String profilePicture, String description, String qrcode) {
        this.userId = userId;
        this.profilePicture = profilePicture;
        this.description = description;
        this.qrcode = qrcode;
    }

    public QrCode(QrCodeDto qrCodeDto) {
        this.id = qrCodeDto.getId();
        this.userId = qrCodeDto.getUserId();
        this.profilePicture = qrCodeDto.getProfilePicture();
        this.description = qrCodeDto.getDescription();
        this.qrcode = qrCodeDto.getQrCode();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getProfilePicture() {
        return profilePicture;
    }

    public void setProfilePicture(String profilePicture) {
        this.profilePicture = profilePicture;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getQrCode() {
        return qrcode;
    }

    public void setQrCode(String qrcode) {
        this.qrcode = qrcode;
    }

}