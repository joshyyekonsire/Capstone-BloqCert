package com.capstone.BloqCert.services;

import com.capstone.BloqCert.dtos.UserDto;
import com.capstone.BloqCert.entities.User;
import com.capstone.BloqCert.repositories.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional
    public List<String> createUser(UserDto userDto) {
        List<String> response = new ArrayList<>();
        User user = new User(userDto);
        userRepository.saveAndFlush(user);
        response.add("http://localhost:8081/XXXXXXXXX.html");
        return response;
    }

    @Override
    public UserDto getUserByEmailAndPassword(String email, String password) {
        Optional<User> user = userRepository.findByEmailAndPassword(email, password);
        if (user.isPresent()) {
            return new UserDto(user.get());
        }
        return null;
    }

    @Override
    public List<UserDto> getAllUsers() {
        return null;
    }
}
