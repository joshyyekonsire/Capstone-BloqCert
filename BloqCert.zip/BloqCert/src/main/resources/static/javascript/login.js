window.addEventListener("DOMContentLoaded", function() {
  const loginForm = document.getElementById("login-form");

  loginForm.addEventListener("submit", handleFormSubmission);

  function handleFormSubmission(event) {
    event.preventDefault();

    const formData = new FormData(loginForm);

    const email = formData.get("email");
    const password = formData.get("password");

    fetch(`http://localhost:8082/users?email=${email}&password=${password}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json"
      }
    })
    .then(response => {
      if (response.ok) {
        return response.json();
      } else {
        throw new Error("Failed to login");
      }
    })
    .then(userDto => {
      if (userDto.email === email && userDto.password === password) {
        alert("Login successful");
        loginForm.reset();

        const user = {
          id: userDto.id,
          firstname: userDto.firstname,
          lastname: userDto.lastname,
          email: userDto.email,
          password: userDto.password
        };

        localStorage.setItem("userId", userDto.id);
        localStorage.setItem("firstname", userDto.firstname);
        localStorage.setItem("lastname", userDto.lastname);
        localStorage.setItem("email", userDto.email);
        localStorage.setItem("password", userDto.password);
        window.location.href = "home.html";

      } else {
        alert("Invalid email or password");
      }
    })
    .catch(error => {
      console.error(error);
      alert("Failed to login");
    });
  }
});