let showcasedItems = [];
const documentContainer = document.querySelector(".document-container");
const showcaseContainer = document.querySelector(".showcase-container");
const profilePictureInput = document.querySelector("#profile-picture");
const profilePicturePreview = document.querySelector(
  "#profile-picture-preview"
);

const firstname = localStorage.getItem("firstname");
const capitalizedFirstname =
  firstname.charAt(0).toUpperCase() + firstname.slice(1);
document.getElementById("firstname").textContent = capitalizedFirstname;

const lastname = localStorage.getItem("lastname");
const capitalizedLastname =
  lastname.charAt(0).toUpperCase() + lastname.slice(1);
document.getElementById("lastname").textContent = capitalizedLastname;

const logoutLink = document.getElementById("logout-btn");
logoutLink.addEventListener("click", clearShowcasedItems);
function clearShowcasedItems() {
  localStorage.removeItem("showcasedItems");
  console.log("showcasedItems cleared");
}

function updateShowcaseSection() {
  showcaseContainer.innerHTML = "";
  showcasedItems = JSON.parse(localStorage.getItem("showcasedItems")) || [];

  showcasedItems.forEach(function (item) {
    const showcaseItem = document.createElement("div");
    showcaseItem.classList.add("showcase-item");

    const showcaseName = document.createElement("span");
    showcaseName.classList.add("showcase-name");
    showcaseName.textContent = item;
    showcaseItem.appendChild(showcaseName);

    const removeButton = document.createElement("button");
    removeButton.classList.add("remove-button");
    removeButton.textContent = "Remove";

    removeButton.addEventListener("click", function () {
      const itemName = showcaseName.textContent;
      const index = showcasedItems.indexOf(itemName);
      if (index !== -1) {
        showcasedItems.splice(index, 1);
        localStorage.setItem("showcasedItems", JSON.stringify(showcasedItems));
      }
    });

    showcaseItem.appendChild(removeButton);

    showcaseContainer.appendChild(showcaseItem);
  });
}
updateShowcaseSection();

profilePictureInput.addEventListener("change", function () {
  const file = this.files[0];
  if (file) {
    const reader = new FileReader();
    reader.addEventListener("load", function () {
      profilePicturePreview.src = reader.result;
    });
    reader.readAsDataURL(file);
  }
});

window.addEventListener("load", function () {
  const firstName = localStorage.getItem("firstname");
  const lastName = localStorage.getItem("lastname");
  const capitalizedFirstName =
    firstName.charAt(0).toUpperCase() + firstName.slice(1);
  const capitalizedLastName =
    lastName.charAt(0).toUpperCase() + lastName.slice(1);
  const userNameHeader = document.getElementById("user-name");
  userNameHeader.textContent = `${capitalizedFirstName} ${capitalizedLastName}`;
});

const populateDocuments = async function () {
  const storedUserId = localStorage.getItem("userId");
  console.log("Attempting to grab documents");

  try {
    const response = await fetch(
      `http://localhost:8082/documents?userId=${storedUserId}`
    );
    if (!response.ok) {
      throw new Error(
        `Network response was not ok: ${response.status} - ${response.statusText}`
      );
    }

    const documents = await response.json();
    console.log(documents);

    documentContainer.innerHTML = "";

    const documentsHeading = document.createElement("h2");
    documentsHeading.classList.add("documents-heading");
    documentsHeading.textContent = "My Documents";
    documentContainer.appendChild(documentsHeading);

    let totalSize = 0;
    for (let i = 0; i < documents.length; i++) {
      const documentData = documents[i].document;
      const documentType = documents[i].type;
      const documentName = documents[i].name;

      const documentFileName = documents[i].fileName;
      const documentUrl = `data:${documentType};base64,${documentData}`;

      const documentItem = document.createElement("div");
      documentItem.classList.add("document-item");

      const documentNameLink = document.createElement("span");
      documentNameLink.classList.add("document-name");
      documentNameLink.textContent = documentName;
      documentItem.appendChild(documentNameLink);

      const viewButton = document.createElement("button");
      viewButton.classList.add("view-button");
      viewButton.textContent = "View";

      viewButton.addEventListener("click", function () {
        window.location.href = documentUrl;
      });

      const addToQrButton = document.createElement("button");
      addToQrButton.classList.add("addToQr-button");
      addToQrButton.textContent = "Add to QR";

      addToQrButton.addEventListener("click", function () {
        showcasedItems.push(documentName);

        const showcaseItem = document.createElement("div");
        showcaseItem.classList.add("showcase-item");

        const showcaseName = document.createElement("span");
        showcaseName.classList.add("showcase-name");
        showcaseName.textContent = documentName;
        showcaseItem.appendChild(showcaseName);

        const removeButton = document.createElement("button");
        removeButton.classList.add("remove-button");
        removeButton.textContent = "Remove";

        showcaseItem.appendChild(removeButton);

        showcaseContainer.appendChild(showcaseItem);

        console.log("showcasedItems: " + showcasedItems);
      });

      showcaseContainer.addEventListener("click", function (event) {
        if (event.target.classList.contains("remove-button")) {
          const showcaseItem = event.target.closest(".showcase-item");
          const itemName =
            showcaseItem.querySelector(".showcase-name").textContent;
          const index = showcasedItems.indexOf(itemName);
          if (index !== -1) {
            showcasedItems.splice(index, 1);
          }
          showcaseItem.remove();
          console.log("showcasedItems: " + showcasedItems);
        }
      });

      const buttonsContainer = document.createElement("div");
      buttonsContainer.classList.add("buttons-container");
      buttonsContainer.appendChild(viewButton);
      buttonsContainer.appendChild(addToQrButton);
      documentItem.appendChild(buttonsContainer);

      documentContainer.appendChild(documentItem);
      console.log("showcasedItems: " + showcasedItems);
    }
  } catch (error) {
    console.error(error);
  }

  async function displayProfile(storedUserId) {
    try {
      const qrCodeResponse = await fetch(
        `http://localhost:8082/qr_codes?userId=${storedUserId}`
      );
      if (!qrCodeResponse.ok) {
        throw new Error(
          `Network response was not ok: ${qrCodeResponse.status} - ${qrCodeResponse.statusText}`
        );
      }

      const qrCodeData = await qrCodeResponse.json();
      console.log(qrCodeData);

      if (qrCodeData.length > 0) {
        const lastQrCode = qrCodeData[qrCodeData.length - 1];

        const decodedProfilePicture = atob(lastQrCode.profilePicture);

        const reconstructedDataURI =
          "data:image/png;base64," + decodedProfilePicture;

        const profilePicturePreview = document.querySelector(
          "#profile-picture-preview"
        );
        profilePicturePreview.src = reconstructedDataURI;

        const descriptionElement = document.querySelector("#description-text");
        if (descriptionElement) {
          descriptionElement.textContent = lastQrCode.description;
        }
      }
    } catch (error) {
      console.error(error);
    }
  }

  displayProfile(storedUserId);

  const saveButton = document.querySelector("#save-button");

  saveButton.addEventListener("click", async function () {
    try {
      const storedUserId = localStorage.getItem("userId");
      const profilePicturePreview = document.querySelector(
        "#profile-picture-preview"
      );

      const profilePictureData = btoa(profilePicturePreview.src.split(",")[1]);

      const descriptionElement = document.querySelector("#profile-description");
      const description = descriptionElement ? descriptionElement.value : "";

      const qrCodeData = {
        userId: storedUserId || "",
        profilePicture: profilePictureData || "",
        profilePictureContentType: "image/png",
        description: description || "",
      };

      console.log("qrCodeData = ", qrCodeData);
      const response = await fetch("http://localhost:8082/qr_codes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(qrCodeData),
      });

      if (!response.ok) {
        throw new Error(
          `Network response was not ok: ${response.status} - ${response.statusText}`
        );
      }

      console.log("QR code data successfully saved.");
    } catch (error) {
      console.error(error);
    }

    localStorage.setItem("showcasedItems", JSON.stringify(showcasedItems));
    console.log("showcasedItems in local storage:" + showcasedItems);

    const storedUserId = localStorage.getItem("userId");
    displayProfile(storedUserId);
  });

  const generateQrCodeButton = document.getElementById(
    "generate-qr-code-button"
  );
  generateQrCodeButton.addEventListener("click", function () {
    console.log("qr hit");
    const storedUserId = localStorage.getItem("userId");
    const url = `http://localhost:63342/BloqCert/static/qrpreview.html?id=${storedUserId}`;
    console.log("Creating qr code for: " + url);
    fetch(`http://localhost:8082/qr_codes/generateQRCode?url=${url}`)
      .then((response) => {
        if (response.ok) {
          return response.blob();
        } else {
          throw new Error("Error generating QR code");
        }
      })
      .then((blob) => {
        const qrCodeImage = URL.createObjectURL(blob);
        console.log("Success:", qrCodeImage);
        const qrCodeModal = document.createElement("div");
        qrCodeModal.classList.add("qr-modal");
        const qrCodeModalContent = document.createElement("div");
        qrCodeModalContent.classList.add("qr-modal-content");
        const qrCodeImageElement = document.createElement("img");
        qrCodeImageElement.classList.add("qr-modal-image");
        qrCodeImageElement.src = qrCodeImage;
        qrCodeModalContent.appendChild(qrCodeImageElement);
        const downloadButton = document.createElement("a");
        downloadButton.classList.add("qr-modal-download-button");
        downloadButton.href = qrCodeImage;
        downloadButton.download = "qr_code.png";
        downloadButton.innerText = "Download";
        qrCodeModalContent.appendChild(downloadButton);

        const closeButton = document.createElement("button");
        closeButton.classList.add("qr-modal-close-button");
        closeButton.innerText = "Close";
        qrCodeModalContent.appendChild(closeButton);

        qrCodeModal.appendChild(qrCodeModalContent);
        document.body.appendChild(qrCodeModal);

        qrCodeModal.addEventListener("click", function (event) {
          if (event.target === qrCodeModal || event.target === closeButton) {
            qrCodeModal.style.display = "none";
          }
        });
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  });
};

window.addEventListener("load", populateDocuments);
