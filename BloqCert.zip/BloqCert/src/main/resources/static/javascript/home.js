window.addEventListener("load", async function () {
  const storedUserId = localStorage.getItem("userId");
  console.log("User ID:", storedUserId);

  const firstname = localStorage.getItem("firstname");
  const capitalizedFirstname =
    firstname.charAt(0).toUpperCase() + firstname.slice(1);
  document.getElementById("firstname").textContent = capitalizedFirstname;

  const grabDocuments = async function () {
    const storedUserId = localStorage.getItem("userId");
    console.log("Attempting to grab documents");

    try {
      const response = await fetch(
        `http://localhost:8082/documents?userId=${storedUserId}`
      );
      if (!response.ok) {
        throw new Error(
          `Network response was not ok: ${response.status} - ${response.statusText}`
        );
      }

      const documents = await response.json();
      console.log(documents);

      const documentsSection = document.getElementById("document-container");
      documentsSection.innerHTML = "";

      const documentsHeading = document.createElement("h2");
      documentsHeading.classList.add("documents-heading");

      documentsSection.appendChild(documentsHeading);

      for (let i = 0; i < documents.length; i++) {
        const documentData = documents[i].document;
        const documentType = documents[i].type;
        const documentName = documents[i].name;
        const documentFileName = documents[i].fileName;
        const documentUrl = `data:${documentType};base64,${documentData}`;

        const documentContainer = document.createElement("div");
        documentContainer.id = "document-containers";

        const documentNameLink = document.createElement("span");
        documentNameLink.classList.add("document-name");
        documentNameLink.textContent = documentName;
        documentContainer.appendChild(documentNameLink);

        const viewButton = document.createElement("button");
        viewButton.classList.add("view-button");
        viewButton.textContent = "View";

        viewButton.addEventListener("click", function () {
          window.location.href = documentUrl;
        });

        const downloadButton = document.createElement("button");
        downloadButton.classList.add("download-button");
        downloadButton.textContent = "Download";

        downloadButton.addEventListener("click", function () {
          const link = document.createElement("a");
          link.href = documentUrl;
          link.download = documentFileName;
          link.click();
        });

        const buttonsContainer = document.createElement("div");
        buttonsContainer.classList.add("buttons-container");
        buttonsContainer.appendChild(viewButton);
        buttonsContainer.appendChild(downloadButton);
        documentContainer.appendChild(buttonsContainer);

        documentsSection.appendChild(documentContainer);
      }
    } catch (error) {
      console.error(error);
    }
  };

  await grabDocuments();

  const uploadButton = document.getElementById("upload-btn");
  const uploadSection = document.getElementById("uploadSection");

  uploadButton.addEventListener("click", uploadDoc);

  async function uploadDoc() {
    const input = document.createElement("input");
    input.type = "file";
    input.accept =
      "application/pdf, image/jpeg, image/png, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document";

    await new Promise((resolve) => {
      input.addEventListener("change", resolve);
      input.click();
    });

    const file = input.files[0];
    console.log("Selected File: ", file);

    const reader = new FileReader();

    reader.onload = async function (event) {
      const listItem = document.createElement("li");
      listItem.classList.add("document-item");
      uploadSection.appendChild(listItem);
      const link = document.createElement("a");
      link.href = URL.createObjectURL(file);
      link.download = file.name;
      link.textContent = file.name;

      const fileSizeInMB = (file.size / (1024 * 1024)).toFixed(2);
      const fileSizeElem = document.createElement("span");
      fileSizeElem.textContent = ` (${fileSizeInMB} MB)`;
      link.appendChild(fileSizeElem);

      const preview = document.createElement("iframe");
      preview.src = link.href;
      preview.style.display = "none";

      link.addEventListener("mouseenter", function () {
        preview.style.display = "block";
      });

      link.addEventListener("mouseleave", function () {
        preview.style.display = "none";
      });

      const addButton = document.createElement("button");
      addButton.classList.add("add-button");
      addButton.textContent = "Add";

      addButton.addEventListener("click", async function () {
        console.log("addButton hit");

        const documentName = file.name;
        const documentType = file.type;
        const documentBytes = btoa(reader.result);
        console.log("storedUserId: " + storedUserId);

        const documentDto = {
          userId: storedUserId,
          name: documentName,
          type: documentType,
          document: documentBytes,
        };

        console.log("Document DTO: ", JSON.stringify(documentDto));

        try {
          const response = await fetch(
            "http://localhost:8082/documents/upload",
            {
              method: "POST",
              body: JSON.stringify(documentDto),
              headers: {
                "Content-Type": "application/json",
              },
            }
          );

          if (!response.ok) {
            throw new Error(
              `Network response was not ok: ${response.status} - ${response.statusText}`
            );
          }

          const data = await response.json();
          console.log("Response Data: ", data);
          grabDocuments();
        } catch (error) {
          if (error instanceof TypeError) {
            console.error(`Network error: ${error.message}`);
          } else {
            console.error(`Error during upload: ${error.message}`);
          }
        }
      });

      const deleteButton = document.createElement("button");
      deleteButton.classList.add("delete-button");
      deleteButton.textContent = "Delete";

      deleteButton.addEventListener("click", function () {
        uploadSection.removeChild(listItem);
      });

      const viewButton = document.createElement("button");
      viewButton.classList.add("view-button");
      viewButton.textContent = "View";

      viewButton.addEventListener("click", function () {
        window.open(link.href);
      });

      listItem.appendChild(link);
      listItem.appendChild(preview);
      listItem.appendChild(addButton);
      listItem.appendChild(deleteButton);
      listItem.appendChild(viewButton);
    };

    reader.readAsBinaryString(file);
  }
});
