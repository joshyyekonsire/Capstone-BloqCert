async function displayProfile(storedUserId) {
  try {
    const qrCodeResponse = await fetch(
      `http://localhost:8082/qr_codes?userId=${storedUserId}`
    );
    if (!qrCodeResponse.ok) {
      throw new Error(
        `Network response was not ok: ${qrCodeResponse.status} - ${qrCodeResponse.statusText}`
      );
    }

    const qrCodeData = await qrCodeResponse.json();
    console.log(qrCodeData);

    if (qrCodeData.length > 0) {
      const lastQrCode = qrCodeData[qrCodeData.length - 1];
      console.log("encoded: " + lastQrCode.profilePicture);
      const decodedProfilePicture = atob(lastQrCode.profilePicture);
      console.log("decoded: " + decodedProfilePicture);
      const reconstructedDataURI =
        "data:image/png;base64," + decodedProfilePicture;
      console.log("reconstructed data URI: " + reconstructedDataURI);

      const profilePicturePreview = document.querySelector(
        "#profile-picture-preview"
      );
      profilePicturePreview.src = reconstructedDataURI;
      const descriptionElement = document.querySelector("#profile-description");
      if (descriptionElement) {
        descriptionElement.textContent = lastQrCode.description;
      }

      const firstName = localStorage.getItem("firstname");
      const lastName = localStorage.getItem("lastname");
      const userNameElement = document.querySelector("#user-name");
      if (userNameElement) {
        userNameElement.textContent = `${capitalize(firstName)} ${capitalize(
          lastName
        )}`;
      }

      const showcasedItems =
        JSON.parse(localStorage.getItem("showcasedItems")) || [];
      const showcaseContainer = document.querySelector(".showcase-container");

      if (showcaseContainer) {
        showcasedItems.forEach((documentName) => {
          const showcaseItem = document.createElement("div");
          showcaseItem.classList.add("showcase-item");

          const itemDetails = document.createElement("div");
          itemDetails.classList.add("item-details");

          const showcaseName = document.createElement("h4");
          showcaseName.classList.add("showcase-name");
          showcaseName.textContent = documentName;
          itemDetails.appendChild(showcaseName);

          const showcaseType = document.createElement("p");
          showcaseType.classList.add("showcase-type");
          itemDetails.appendChild(showcaseType);

          const viewButton = document.createElement("button");
          viewButton.classList.add("view-button");
          viewButton.textContent = "View";
          viewButton.addEventListener("click", () => {});
          itemDetails.appendChild(viewButton);

          showcaseItem.appendChild(itemDetails);

          showcaseContainer.appendChild(showcaseItem);
        });
      }
    }
  } catch (error) {
    console.error(error);
  }
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

const storedUserId = localStorage.getItem("userId");
displayProfile(storedUserId);
