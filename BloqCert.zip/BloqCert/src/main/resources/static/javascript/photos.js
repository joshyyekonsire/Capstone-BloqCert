const storedUserId = localStorage.getItem("userId");

const firstname = localStorage.getItem("firstname");
const lastname = localStorage.getItem("lastname");
const capitalizedFirstname =
  firstname.charAt(0).toUpperCase() + firstname.slice(1);
document.getElementById("firstname").textContent = capitalizedFirstname;
const capitalizedLastname =
  lastname.charAt(0).toUpperCase() + lastname.slice(1);
document.getElementById("lastname").textContent = capitalizedLastname;

async function fetchPhotos(userId) {
  try {
    const response = await fetch(
      `http://localhost:8082/qr_codes?userId=${userId}`
    );
    if (!response.ok) {
      throw new Error(
        `Network response was not ok: ${response.status} - ${response.statusText}`
      );
    }

    const data = await response.json();
    console.log(data);

    return data;
  } catch (error) {
    console.error(error);
  }
}

function createTableRow() {
  const tableRow = document.createElement("tr");
  return tableRow;
}

function createTableCell() {
  const tableCell = document.createElement("td");
  return tableCell;
}

async function populateTable() {
  const photosData = await fetchPhotos(storedUserId);

  if (photosData && Array.isArray(photosData)) {
    const tableBody = document.getElementById("table-body");
    let tableRow = createTableRow();

    photosData.forEach((photo, index) => {
      console.log("Profile Picture:", photo.profilePicture);
      const decodedProfilePicture = atob(photo.profilePicture);
      const reconstructedDataURI =
        "data:image/png;base64," + decodedProfilePicture;

      const tableCell = createTableCell();
      const imgElement = document.createElement("img");
      imgElement.src = reconstructedDataURI;
      imgElement.classList.add("photo");
      tableCell.appendChild(imgElement);
      tableRow.appendChild(tableCell);

      if ((index + 1) % 4 === 0) {
        tableBody.appendChild(tableRow);
        tableRow = createTableRow();
      }
    });

    if (tableRow.children.length > 0) {
      tableBody.appendChild(tableRow);
    }
  }
}

populateTable();
