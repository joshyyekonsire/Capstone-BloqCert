document.addEventListener("DOMContentLoaded", function () {
  const subscribeForm = document.getElementById("subscribe-form");
  const confirmPasswordField = document.getElementById("confirm-password");

  subscribeForm.addEventListener("submit", handleFormSubmission);

  function handleFormSubmission(event) {
    event.preventDefault();

    const formData = new FormData(subscribeForm);

    const password = formData.get("password");
    const confirmPassword = formData.get("confirm-password");

    if (password !== confirmPassword) {
      alert("Passwords do not match");
      return;
    }

    const firstname = formData.get("firstname");
    const lastname = formData.get("lastname");
    const email = formData.get("email");

    const userDto = {
      firstname: firstname,
      lastname: lastname,
      email: email,
      password: password,
    };
    console.log(userDto);
    fetch("http://localhost:8082/users/register", {
      method: "POST",
      body: JSON.stringify(userDto),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => {
        if (response.ok) {
          alert("User created successfully");
          subscribeForm.reset();
          window.location.href = "login.html";
        } else {
          console.log(response);
          alert("Failed to create user");
        }
      })
      .catch((error) => {
        console.log(response);
        console.error(error);
        alert("Failed to create user");
      });
  }
});
