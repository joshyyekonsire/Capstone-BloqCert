
document.addEventListener("DOMContentLoaded", function () {
  const userInfoSection = document.querySelector("main section");
  const changePasswordBtn = document.getElementById("change-password-btn");
  const logoutBtn = document.getElementById("logout-btn");

  const userId = localStorage.getItem("userId");
  const firstname = localStorage.getItem("firstname");
  const lastname = localStorage.getItem("lastname");
  const email = localStorage.getItem("email");
  const password = localStorage.getItem("password");
  console.log("-------");
  console.log("userId: " + userId);
  console.log("firstname: " + firstname);
  console.log("lastname: " + lastname);
  console.log("email: " + email);
  console.log("password: " + password);

  const capitalizedFirstname =
    firstname.charAt(0).toUpperCase() + firstname.slice(1);
  document.getElementById("firstname").textContent = capitalizedFirstname;

  const capitalizedLastname =
    lastname.charAt(0).toUpperCase() + lastname.slice(1);
  document.getElementById("lastname").textContent = capitalizedLastname;

  console.log("-------");
  if (!userId) {
    window.location.href = "login.html";
  } else {
    userInfoSection.innerHTML = `
      <h2>Account Information</h2>
      <p><strong>First Name:</strong> ${firstname}</p>
      <p><strong>Last Name:</strong> ${lastname}</p>
      <p><strong>Email:</strong> ${email}</p>
      <p><strong>Password:</strong> ${password}</p>
      <button id="change-password-btn">Change Password</button>
    `;
  }

  logoutBtn.addEventListener("click", function () {
    localStorage.removeItem("userId");
    localStorage.removeItem("firstname");
    localStorage.removeItem("lastname");
    localStorage.removeItem("email");
    localStorage.removeItem("password");
    window.location.href = "login.html";
  });
});