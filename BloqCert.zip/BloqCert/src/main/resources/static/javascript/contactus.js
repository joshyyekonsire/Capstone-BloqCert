const form = document.getElementById("contact-form");
const submitButton = form.querySelector('input[type="submit"]');
const firstname = localStorage.getItem("firstname");
const lastname = localStorage.getItem("lastname");
const capitalizedFirstname =
  firstname.charAt(0).toUpperCase() + firstname.slice(1);
document.getElementById("firstname").textContent = capitalizedFirstname;
const capitalizedLastname =
  lastname.charAt(0).toUpperCase() + lastname.slice(1);
document.getElementById("lastname").textContent = capitalizedLastname;

submitButton.addEventListener("click", (event) => {
  event.preventDefault();

  const modal = document.createElement("div");
  modal.classList.add("modal");

  const content = document.createElement("div");
  content.classList.add("modal-content");
  content.innerHTML =
    '<p style="color: green;">Your message has been successfully sent!</p><p>We will reach out to you in 1-2 business days.</p><p>If this is urgent, you may contact us during normal business hours at 385 309 8000</p><p>Thank you</p>';

  const closeButton = document.createElement("span");
  closeButton.classList.add("close");
  closeButton.textContent = "×";
  closeButton.addEventListener("click", () => modal.remove());

  content.appendChild(closeButton);
  modal.appendChild(content);
  document.body.appendChild(modal);

  form.reset();
});
