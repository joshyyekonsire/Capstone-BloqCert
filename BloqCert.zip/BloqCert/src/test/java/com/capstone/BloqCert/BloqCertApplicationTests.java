package com.capstone.BloqCert;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BloqCertApplicationTests {

	@Test
	void contextLoads() {
	}

}
